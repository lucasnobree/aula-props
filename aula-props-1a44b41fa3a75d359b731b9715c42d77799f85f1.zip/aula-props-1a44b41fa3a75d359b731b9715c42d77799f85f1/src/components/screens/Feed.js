import React from 'react';
import { View, Text } from 'react-native';

const Feed = () => {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Feed Screen</Text>
    </View>
  );
};

export default Feed;
